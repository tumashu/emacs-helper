(define-package "pyim" "20200211.210" "A Chinese input method support quanpin, shuangpin, wubi and cangjie."
  '((emacs "24.4")
    (popup "0.1")
    (async "1.6")
    (xr "1.13")
    (pyim-basedict "0.1")))
;; Local Variables:
;; no-byte-compile: t
;; End:
