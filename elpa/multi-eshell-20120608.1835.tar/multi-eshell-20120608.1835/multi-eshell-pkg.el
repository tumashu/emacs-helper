;;; -*- no-byte-compile: t -*-
(define-package "multi-eshell" "20120608.1835" "Create and manage multiple shells within Emacs" 'nil)
