;;; Generated package description from /home/feng/.emacs.d/elpa/lv-20200122.1200/lv.el  -*- no-byte-compile: t -*-
(define-package "lv" "20200122.1200" "Other echo area" 'nil :commit "e3beffdd804b87b20c87d7fb8e37d6eee2b0d763" :authors '(("Oleh Krehel")) :maintainer '("Oleh Krehel"))
