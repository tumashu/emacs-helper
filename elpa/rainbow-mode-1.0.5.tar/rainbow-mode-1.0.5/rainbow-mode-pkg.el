;;; Generated package description from /home/feng/.emacs.d/elpa-28/rainbow-mode-1.0.5/rainbow-mode.el  -*- no-byte-compile: t -*-
(define-package "rainbow-mode" "1.0.5" "Colorize color names in buffers" 'nil :url "http://elpa.gnu.org/packages/rainbow-mode.html" :keywords '("faces") :authors '(("Julien Danjou" . "julien@danjou.info")) :maintainer '("Julien Danjou" . "julien@danjou.info"))
