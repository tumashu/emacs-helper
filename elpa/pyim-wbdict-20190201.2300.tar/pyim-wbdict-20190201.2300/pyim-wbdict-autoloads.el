;;; pyim-wbdict-autoloads.el --- automatically extracted autoloads
;;
;;; Code:

(add-to-list 'load-path (directory-file-name
                         (or (file-name-directory #$) (car load-path))))


;;;### (autoloads nil "pyim-wbdict" "pyim-wbdict.el" (0 0 0 0))
;;; Generated autoloads from pyim-wbdict.el

(autoload 'pyim-wbdict-v98-enable "pyim-wbdict" "\
Add wubi dict (98 version) to pyim.

\(fn)" t nil)

(define-obsolete-function-alias 'pyim-wbdict-gbk-enable 'pyim-wbdict-v98-enable)

;;;***

;;;### (autoloads nil nil ("pyim-wbdict-pkg.el") (0 0 0 0))

;;;***

;; Local Variables:
;; version-control: never
;; no-byte-compile: t
;; no-update-autoloads: t
;; coding: utf-8
;; End:
;;; pyim-wbdict-autoloads.el ends here
