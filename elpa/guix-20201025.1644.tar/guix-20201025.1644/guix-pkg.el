(define-package "guix" "20201025.1644" "Interface for GNU Guix"
  '((emacs "24.3")
    (dash "2.11.0")
    (geiser "0.8")
    (bui "1.2.0")
    (magit-popup "2.1.0")
    (edit-indirect "0.1.4"))
  :commit "41fba4eec845e050be92bfe76c0f7980bbe821bd" :keywords
  '("tools")
  :authors
  '(("Alex Kost" . "alezost@gmail.com"))
  :maintainer
  '("Alex Kost" . "alezost@gmail.com")
  :url "https://emacs-guix.gitlab.io/website/")
;; Local Variables:
;; no-byte-compile: t
;; End:
