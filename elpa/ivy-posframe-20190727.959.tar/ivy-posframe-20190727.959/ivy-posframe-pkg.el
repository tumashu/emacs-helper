;;; -*- no-byte-compile: t -*-
(define-package "ivy-posframe" "20190727.959" "Using posframe to show Ivy" '((emacs "26.0") (posframe "0.1.0") (ivy "0.11.0")) :commit "8ad466802de90d47992024394ea5f864c1cf0ac1" :keywords '("abbrev" "convenience" "matching" "ivy") :authors '(("Feng Shu")) :maintainer '("Feng Shu" . "tumashu@163.com") :url "https://github.com/tumashu/ivy-posframe")
