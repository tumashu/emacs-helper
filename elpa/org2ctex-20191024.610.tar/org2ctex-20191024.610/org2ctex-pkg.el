;;; -*- no-byte-compile: t -*-
(define-package "org2ctex" "20191024.610" "Export org to ctex (a latex macro for Chinese)" '((emacs "24.4")) :commit "d4af170f5190dad3aa31ab1cf4c6f087d56ab111" :authors '(("Feng Shu" . "tumashu@163.com")) :maintainer '("Feng Shu" . "tumashu@163.com") :url "https://github.com/tumashu/org2ctex")
