(define-package "guix" "20200730.930" "Interface for GNU Guix"
  '((emacs "24.3")
    (dash "2.11.0")
    (geiser "0.8")
    (bui "1.2.0")
    (magit-popup "2.1.0")
    (edit-indirect "0.1.4"))
  :commit "58a840d0671091e3064e36244790ef8839da87d6" :keywords
  '("tools")
  :authors
  '(("Alex Kost" . "alezost@gmail.com"))
  :maintainer
  '("Alex Kost" . "alezost@gmail.com")
  :url "https://emacs-guix.gitlab.io/website/")
;; Local Variables:
;; no-byte-compile: t
;; End:
