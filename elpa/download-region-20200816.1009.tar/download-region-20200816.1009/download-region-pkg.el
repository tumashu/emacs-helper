;;; Generated package description from /home/feng/.emacs.d/elpa-28/download-region-20200816.1009/download-region.el  -*- no-byte-compile: t -*-
(define-package "download-region" "20200816.1009" "Simple in-buffer download manager" '((cl-lib "0.3")) :commit "0dca3b224649bba80a7e9ecbf1d1b6f6be962455" :authors '(("zk_phi")) :maintainer '("zk_phi") :url "http://zk-phi.github.io/")
