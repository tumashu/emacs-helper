(define-package "emms" "20191106.1933" "The Emacs Multimedia System"
  '((cl-lib "0.5"))
  :keywords
  '("emms" "mp3" "mpeg" "multimedia")
  :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schäfer" . "forcer@forcix.cx")
  :url "http://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
