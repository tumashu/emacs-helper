;; Generated package description from xr.el  -*- no-byte-compile: t -*-
(define-package "xr" "1.15" "Convert string regexp to rx notation" '((emacs "26.1")) :keywords '("lisp" "regexps") :authors '(("Mattias Engdegård" . "mattiase@acm.org")) :maintainer '("Mattias Engdegård" . "mattiase@acm.org") :url "https://github.com/mattiase/xr")
