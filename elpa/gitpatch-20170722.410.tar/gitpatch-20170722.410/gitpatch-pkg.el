;;; -*- no-byte-compile: t -*-
(define-package "gitpatch" "20170722.410" "Git-format patch toolkit" '((emacs "24.3")) :commit "577d5adf65c8133caa325c10e89e1e2fc323c907" :keywords '("convenience") :authors '(("Feng Shu" . "tumashu@163.com")) :maintainer '("Feng Shu" . "tumashu@163.com") :url "https://github.com/tumashu/gitpatch")
