(define-package "company-posframe" "20200210.2131" "Use a posframe as company candidate menu"
  '((emacs "26.0")
    (company "0.9.0")
    (posframe "0.1.0"))
  :keywords
  '("abbrev" "convenience" "matching")
  :authors
  '(("Clément Pit-Claudel, Feng Shu, Lars Andersen" . "expez@expez.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :url "https://github.com/tumashu/company-posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
