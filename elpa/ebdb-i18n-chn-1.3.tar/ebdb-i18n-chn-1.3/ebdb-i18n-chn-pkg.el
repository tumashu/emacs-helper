;;; -*- no-byte-compile: t -*-
(define-package "ebdb-i18n-chn" "1.3" "China-specific internationalization support for EBDB" '((pyim "1.6.0") (ebdb "0.2")) :url "http://elpa.gnu.org/packages/ebdb-i18n-chn.html" :authors '(("Eric Abrahamsen" . "eric@ericabrahamsen.net")) :maintainer '("Eric Abrahamsen" . "eric@ericabrahamsen.net"))
