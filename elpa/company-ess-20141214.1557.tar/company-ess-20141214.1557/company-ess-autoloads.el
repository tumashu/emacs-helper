;;; company-ess-autoloads.el --- automatically extracted autoloads
;;
;;; Code:
(add-to-list 'load-path (or (file-name-directory #$) (car load-path)))

;;;### (autoloads nil "company-ess" "company-ess.el" (0 0 0 0))
;;; Generated autoloads from company-ess.el

(autoload 'company-ess-backend "company-ess" "\
R/ESS backend for company-mode.

\(fn COMMAND &optional ARG &rest IGNORED)" t nil)

(if (fboundp 'register-definition-prefixes) (register-definition-prefixes "company-ess" '("company-ess-" "ess-company-candidates")))

;;;***

;;;### (autoloads nil nil ("company-ess-pkg.el") (0 0 0 0))

;;;***

;; Local Variables:
;; version-control: never
;; no-byte-compile: t
;; no-update-autoloads: t
;; End:
;;; company-ess-autoloads.el ends here
