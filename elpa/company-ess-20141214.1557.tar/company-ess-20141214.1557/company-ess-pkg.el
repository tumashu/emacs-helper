;;; -*- no-byte-compile: t -*-
(define-package "company-ess" "20141214.1557" "R/ess Completion Backend for company-mode" '((company "0.8.0") (ess "13.5") (cl-lib "0.5") (emacs "24.1")) :url "https://github.com/Lompik/company-ess" :keywords '("completion" "ess"))
