;;; -*- no-byte-compile: t -*-
(define-package "elpa-mirror" "20190622.730" "Create local package repository from installed packages" '((emacs "24.4")) :commit "468adfff8dedb024b90af0e66434dc50de259714" :keywords '("maint" "tools") :authors '(("Chen Bin" . "chenbin.sh@gmail.com")) :maintainer '("Chen Bin" . "chenbin.sh@gmail.com") :url "http://github.com/redguardtoo/elpa-mirror")
