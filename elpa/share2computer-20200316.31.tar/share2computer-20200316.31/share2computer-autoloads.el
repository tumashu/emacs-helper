;;; share2computer-autoloads.el --- automatically extracted autoloads
;;
;;; Code:

(add-to-list 'load-path (directory-file-name
                         (or (file-name-directory #$) (car load-path))))


;;;### (autoloads nil "share2computer" "share2computer.el" (0 0 0
;;;;;;  0))
;;; Generated autoloads from share2computer.el

(autoload 'share2computer-kill "share2computer" "\
Kill all share2computer downloads." t nil)

(autoload 'share2computer "share2computer" "\
Download files shared by Android ShareToComputer." t nil)

(autoload 'share2computer-org "share2computer" "\
Download files shared by Android ShareToComputer to org attach dir." t nil)

(register-definition-prefixes "share2computer" '("share2computer-"))

;;;***

;; Local Variables:
;; version-control: never
;; no-byte-compile: t
;; no-update-autoloads: t
;; coding: utf-8
;; End:
;;; share2computer-autoloads.el ends here
