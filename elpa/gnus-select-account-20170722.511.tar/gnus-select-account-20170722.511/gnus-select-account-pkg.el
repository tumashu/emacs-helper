;;; -*- no-byte-compile: t -*-
(define-package "gnus-select-account" "20170722.511" "Select an account before writing a mail in gnus" 'nil :commit "ddc8c135eeaf90f5b6692a033af2badae36e68ce" :keywords '("convenience") :authors '(("Feng Shu " . "tumashu@163.com")) :maintainer '("Feng Shu " . "tumashu@163.com") :url "https://github.com/tumashu/gnus-select-account")
