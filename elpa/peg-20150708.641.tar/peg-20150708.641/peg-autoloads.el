;;; peg-autoloads.el --- automatically extracted autoloads
;;
;;; Code:

(add-to-list 'load-path (directory-file-name
                         (or (file-name-directory #$) (car load-path))))


;;;### (autoloads nil "peg" "peg.el" (0 0 0 0))
;;; Generated autoloads from peg.el

(register-definition-prefixes "peg" '("peg-"))

;;;***

;;;### (autoloads nil nil ("peg-pkg.el") (0 0 0 0))

;;;***

;; Local Variables:
;; version-control: never
;; no-byte-compile: t
;; no-update-autoloads: t
;; coding: utf-8
;; End:
;;; peg-autoloads.el ends here
